#' @title 
#' Download files from the ftp server "oceane.obs-vlfr.fr"
#'
#' @description 
#' Download files used by \code{cl_GetData()} function.
#'
#' @param month : [integer] decimal month (0-12). Default = 0.
#'                          0 indicates the climatology over 21 years (1998-2018).
#'                          1 to 12 indicates the decimal value for a single month (1 = January, ...);
#'                          
#'
#' @param DownloadGeo : [logical] download the "geographic" file containing
#'                 longitude, latitude, depth and surface area of the pixels, mandatory for retrieving pixel locations
#'                 (default = TRUE)
#'
#' @param dirdata : [character] The directory where the files are stored (default = "./CoastalLight.d");
#'
#' @return : none
#'
#' @examples
#' cl_DownloadData()
cl_DownloadData <- function(month = 0, DownloadGeo = TRUE, dirdata = "CoastalLight.d") {
	if(! file.exists(dirdata)) {
		dir.create(dirdata)
		cat("directory", dirdata, "created\n")
	}
#	url <- paste("ftp://oceane.obs-vlfr.fr/pub/gentili/CoastalLight", f, sep = "/")
	if(DownloadGeo) {
		f <- paste(paste("CoastalLight", "geo", sep = "_"), "nc", sep = ".")
#		url <- paste("file:///data/home/gentili/Documents/COTIER/Cotier2019_15secRegion/MetaRegionsNEW/World1", f, sep = "/")
		url <- paste("ftp://oceane.obs-vlfr.fr/pub/gentili/CoastalLight", f, sep = "/")
		localf <- paste(dirdata, f, sep = "/")
		if(! file.exists(localf)) {
			cat("downloading", f, "\n")
			download.file(url, localf)
		} else {
			cat(f, "already downloaded in directory", dirdata, "\n")
		}
	}
	cmonth <- formatC(month, format = "d", width = 2, flag = "0")
	f <- paste(paste("CoastalLight", cmonth, sep = "_"), "nc", sep = ".")
#	url <- paste("file:///data/home/gentili/Documents/COTIER/Cotier2019_15secRegion/MetaRegionsNEW/World1", f, sep = "/")
	url <- paste("ftp://oceane.obs-vlfr.fr/pub/gentili/CoastalLight", f, sep = "/")
	localf <- paste(dirdata, f, sep = "/")
	if(! file.exists(localf)) {
		cat("downloading", f, "\n")
		download.file(url, localf)
	} else {
		cat(f, "already downloaded in directory", dirdata, "\n")
	}
}
